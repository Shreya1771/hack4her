<?php

class Api extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->model('tc_model');
    }
    function index(){
        echo base_url();
    }

    function add_account(){
        $post = $this->input->post(NULL,TRUE);
        $outputVal['smlei_api'] = array(
            'status' => array(
                'result' => '0',
                'message' => 'error'
            )
        );
        $result = $this->tc_model->add_account($post);

        if($result) {
            //return true;
            $outputVal['smlei_api']['status']['result'] = 1;
            $outputVal['smlei_api']['status']['message'] = $result;
        }
        else
        {
            //return false;
            $outputVal['smlei_api']['status']['result'] = 0;
            $outputVal['smlei_api']['status']['message'] = "error";
        }
        $this->display_output($outputVal);
    }

    function display_output($outputVal){
        $this->output->set_header("Content-Type: application/json; charset=utf-8");
        $jsonOutput = json_encode($outputVal);
        $this->output->set_output($jsonOutput);
    }
}
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/17/15
 * Time: 4:43 PM
 */ 