<?php
class Tc_model extends CI_Model{

    function add_account($post){
        $new_image_inset_details = array(
            'username'  => (array_key_exists('username', $post))? urldecode($post['username']): null,
            'pin'     => (array_key_exists('pin', $post))? urldecode($post['pin']): null,
        );
        $insert = $this->db->insert('tc_accounts', $new_image_inset_details);
        if($insert){
            return true;
        }
        else{
            return false;
        }
    }
}
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/17/15
 * Time: 5:07 PM
 */ 